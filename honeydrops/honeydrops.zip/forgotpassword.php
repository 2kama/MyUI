<?php include("header.php"); ?>








   <div class="container-fluid" style="background: url('img/backback.png') no-repeat center center / cover; min-height: 140vh;">
   	
		<div class="row">
			

				<div class="col-md-4 offset-md-4">

					<div class="credential">
						
						<span>FORGOT PASSWORD</span>

                        <p style="text-align: left;">
                        	Enter yor account email to recieve a link allowing you to reset your password
                        </p>

						<div class="row" style="margin-top: 30px;">
							
								<div class="col-md-12">
								  <form action="">
									<label for="">Email</label>
									<input type="email" class="form-control">

									<button class="btn col-md-4 offset-md-4">REQUEST RESET</button>

									<p>Return to <a href="#">Sign in</a></p>
								  </form>
								</div>
								

							
						</div>

					</div>
					

					
					

				</div>


		</div>


   </div>

		











    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/popper.js" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" crossorigin="anonymous"></script>
    <script src="js/main.js"></script>
  </body>
</html>