<?php include("header.php"); ?>








   <div class="container-fluid" style="background: url('img/backback.png') no-repeat center center / cover; min-height: 140vh;">
   	
		<div class="row">
			

				<div class="col-md-4 offset-md-4">

					<div class="credential">
						
						<div class="row" style="padding-top: 10px;">
						
							<a href="" style="width: 100%;"><button class="btn btn-block auth" style="background: #4a67ad;"><i class="fa fa-facebook-square"></i>Login with Facebook</button></a>

							<a href="" style="width: 100%;"><button class="btn btn-block auth" style="background: #db3236;"><i class="fa fa-google"></i>Login with Google</button></a>

						</div>

						<div class="row" style="margin-top: 30px;color: #d8d8d8;">
							<div class="col-5"><hr></div>
							<div class="col-2 text-center">or</div>
							<div class="col-5"><hr></div>
						</div>

						<div class="row" style="margin-top: 30px;">
							
								<div class="col-md-12">
								  <form action="">
									<label for="">Username</label>
									<input type="text" class="form-control">

									<label for="">Password</label>
									<input type="password" class="form-control">

									<button class="btn col-md-4 offset-md-4">SIGN IN</button>

									<p><a href="#">I forgot my password</a></p>

									<p>Don't have an account ? <a href="#">Sign up</a></p>
								  </form>
								</div>
								

							
						</div>

					</div>
					

					
					

				</div>


		</div>


   </div>

		











    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/popper.js" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" crossorigin="anonymous"></script>
    <script src="js/main.js"></script>
  </body>
</html>