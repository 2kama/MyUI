



<div class="container-fluid" style="background: #212121;padding-top: 30px;padding-bottom:20px;">
    <div class="container">
      
        <div class="row anaky" style="border-bottom: 1px solid #777;">
          
            <div class="col-m">
               <h6>Categories</h6>
               <p>Careers</p>
               <p>Press and news</p>
               <p>Partnership</p>
               <p>Privacy policy</p>
               <p>Terms of service</p>
               <p>Offer a Service</p>
            </div>


            <div class="col-m">
               <h6>Community</h6>
               <p>Blog</p>
               <p>Forum</p>
               <p>Podcast</p>
               <p>Affiliates</p>
               <p>Invite a friend</p>
            </div>


            <div class="col-m">
               <h6>Support</h6>
               <p>Contact support</p>
               <p>Help and Education</p>
               <p>Trust and Safety</p>
               <p>Selling on Footprints</p>
               <p>Buying on Footprinnts</p>
            </div>   
            

            <div class="col-m">
               <h6>Get Documents</h6>
               <p>Categories</p>
               <p>Process</p>
               <p>Payment</p>
            </div>


            <div class="col-m">
               <h6>Support</h6>
               <p>Contact support</p>
               <p>Help and Education</p>
               <p>Trust and Safety</p>
               <p>Selling on Footprints</p>
               <p>Buying on Footprinnts</p>
            </div>          
            

        </div>

        <div class="row foot">
          <div class="col-md-4 offset-md-8">
              <a href="#"><i class="fa fa-facebook"></i></a>
                 <a href="#"><i class="fa fa-twitter"></i></a>
                 <a href="#"><i class="fa fa-google-plus"></i></a>
                 <a href="#"><i class="fa fa-linkedin"></i></a>
                 <a href="#"><i class="fa fa-instagram"></i></a>
          </div>
        </div>


    </div>
</div>
      



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/popper.js" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" crossorigin="anonymous"></script>
    <script src="js/main.js"></script>
  </body>
</html>