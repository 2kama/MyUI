 <?php include('header.php'); ?>


  <style>
  	nav.navbar {
  		 background: #e6e6e6;
  	}
  	body {
  		background: #f7f8fa;
  	}
  </style>





   <div class="container-fluid breadcrum" style="margin-top: 50px;">
   	  <div class="container">
   	  	   <a href="">Home</a> | <a href="">Find lawyer</a> | <a href="">Search Result</a>
   	  </div>
        
   	</div>


   	<div class="container" style="padding-top: 10px; padding-bottom: 10px;"> 

          
             <img src="img/banner.png" style="width: 100%;" alt="">
         

      </div>

   


   <div class="container-fluid" style="padding-top: 0px;min-height: 100vh;">
   	<div class="container">
   		

		<div class="row">
			<div class="col-md-3 sideBin">
				
				<button class="btn topSand" type="button" data-toggle="collapse" data-target="#locationcollapseExample" aria-expanded="false" aria-controls="locationcollapseExample">
				    Location <i class="material-icons" style="float: right;">arrow_drop_down</i>
				  </button>

				  <div class="locationShow" id="locationcollapseExample">
					  <form>
						  <div class="form-group">
						    <input type="text" class="form-control locationSearcher" placeholder="Search a location">
						  </div>
						</form>

						<label class="containers">&emsp;Lagos(103)
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<label class="containers">&emsp;Lagos(103)
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<label class="containers">&emsp;Lagos(103)
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<label class="containers">&emsp;Lagos(103)
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<label class="containers">&emsp;Lagos(103)
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<a href="#" class="all">see all</a>
					  
					</div>



					<button class="btn topSand" type="button" data-toggle="collapse" data-target="#categorycollapseExample" aria-expanded="false" aria-controls="categorycollapseExample">
				    Service Category <i class="material-icons" style="float: right;">arrow_drop_down</i>
				  </button>

				  <div class="locationShow" id="categorycollapseExample">
					  <form>
						  <div class="form-group">
						    <input type="text" class="form-control locationSearcher" placeholder="Search a Category">
						  </div>
						</form>

						<label class="containers">&emsp;Lagos(103)
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<label class="containers">&emsp;Lagos(103)
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<label class="containers">&emsp;Lagos(103)
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<label class="containers">&emsp;Lagos(103)
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<label class="containers">&emsp;Lagos(103)
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<a href="#" class="all">see all</a>
					  
					</div>





				 <button class="btn topSand" type="button" data-toggle="collapse" data-target="#pricecollapseExample" aria-expanded="false" aria-controls="pricecollapseExample">
				    Price <i class="material-icons" style="float: right;">arrow_drop_down</i>
				  </button>

				  <div class="locationShow" id="pricecollapseExample">
					  

						<label class="containers">&emsp;15,000 - 20,000
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<label class="containers">&emsp;Lagos(103)
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<label class="containers">&emsp;Lagos(103)
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<label class="containers">&emsp;Lagos(103)
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<label class="containers">&emsp;Lagos(103)
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>

						<a href="#" class="all">see all</a>
					  
					</div>


			</div>



			<div class="col-md-9">
				<div class="col-md-12">
					<div class="row fat">
						<div class="col-md-12">
							<h5>search result for " business law "</h5>

							<span>24 Search result</span>
						</div>
						
					</div>



					<!-- vendors listing -->

					<div class="col-md-12 venor">
						<div class="row">
							
							<div class="col-md-2">
								<img src="img/lawyer1.png" alt="...">
							</div>

							<div class="col-md-8">
								<span>Oluwagbemiga joshua</span>
								<p class="statement">
									We are a full-service business, litigation and probate law firm with offices in victoria island , Lagos. The firm's seven attorneys have decades of extensive experience in litigation, business...
								</p>

								<p class="statement"><i class="material-icons vote">star</i> 4.0 (67 clients) </p>
							</div>

							<div class="col-md-2 text-center">
							    <p class="statement"><span class="dot"></span> Available</p>
								<p class="price">&#8358;20,000</p>
									
								<button type="button" class="btn btn-block">CONTACT</button>
							</div>	
								
				
								
							</div>
						</div>
			
					<!--vendor -->



					<!-- vendors listing -->

					<div class="col-md-12 venor">
						<div class="row">
							
							<div class="col-md-2">
								<img src="img/lawyer2.png" alt="...">
							</div>

							<div class="col-md-8">
								<span>Oluwagbemiga joshua</span>
								<p class="statement">
									We are a full-service business, litigation and probate law firm with offices in victoria island , Lagos. The firm's seven attorneys have decades of extensive experience in litigation, business...
								</p>

								<p class="statement"><i class="material-icons vote">star</i> 4.0 (67 clients) </p>
							</div>

							<div class="col-md-2 text-center">
							    <p class="statement"><span class="dot"></span> Available</p>
								<p class="price">&#8358;20,000</p>
									
								<button type="button" class="btn btn-block">CONTACT</button>
							</div>	
								
				
								
							</div>
						</div>
			
					<!--vendor -->


					<!-- vendors listing -->

					<div class="col-md-12 venor">
						<div class="row">
							
							<div class="col-md-2">
								<img src="img/lawyer3.png" alt="...">
							</div>

							<div class="col-md-8">
								<span>Oluwagbemiga joshua</span>
								<p class="statement">
									We are a full-service business, litigation and probate law firm with offices in victoria island , Lagos. The firm's seven attorneys have decades of extensive experience in litigation, business...
								</p>

								<p class="statement"><i class="material-icons vote">star</i> 4.0 (67 clients) </p>
							</div>

							<div class="col-md-2 text-center">
							    <p class="statement"><span class="dot"></span> Available</p>
								<p class="price">&#8358;20,000</p>
									
								<button type="button" class="btn btn-block">CONTACT</button>
							</div>	
								
				
								
							</div>
						</div>
			
					<!--vendor -->


					<!-- vendors listing -->

					<div class="col-md-12 venor">
						<div class="row">
							
							<div class="col-md-2">
								<img src="img/lawyer4.png" alt="...">
							</div>

							<div class="col-md-8">
								<span>Oluwagbemiga joshua</span>
								<p class="statement">
									We are a full-service business, litigation and probate law firm with offices in victoria island , Lagos. The firm's seven attorneys have decades of extensive experience in litigation, business...
								</p>

								<p class="statement"><i class="material-icons vote">star</i> 4.0 (67 clients) </p>
							</div>

							<div class="col-md-2 text-center">
							    <p class="statement"><span class="dot"></span> Available</p>
								<p class="price">&#8358;20,000</p>
									
								<button type="button" class="btn btn-block">CONTACT</button>
							</div>	
								
				
								
							</div>
						</div>
			
					<!--vendor -->



					<!-- vendors listing -->

					<div class="col-md-12 venor">
						<div class="row">
							
							<div class="col-md-2">
								<img src="img/lawyer5.png" alt="...">
							</div>

							<div class="col-md-8">
								<span>Oluwagbemiga joshua</span>
								<p class="statement">
									We are a full-service business, litigation and probate law firm with offices in victoria island , Lagos. The firm's seven attorneys have decades of extensive experience in litigation, business...
								</p>

								<p class="statement"><i class="material-icons vote">star</i> 4.0 (67 clients) </p>
							</div>

							<div class="col-md-2 text-center">
							    <p class="statement"><span class="dot"></span> Available</p>
								<p class="price">&#8358;20,000</p>
									
								<button type="button" class="btn btn-block">CONTACT</button>
							</div>	
								
				
								
							</div>
						</div>
			
					<!--vendor -->



					<!-- vendors listing -->

					<div class="col-md-12 venor">
						<div class="row">
							
							<div class="col-md-2">
								<img src="img/lawyer6.png" alt="...">
							</div>

							<div class="col-md-8">
								<span>Oluwagbemiga joshua</span>
								<p class="statement">
									We are a full-service business, litigation and probate law firm with offices in victoria island , Lagos. The firm's seven attorneys have decades of extensive experience in litigation, business...
								</p>

								<p class="statement"><i class="material-icons vote">star</i> 4.0 (67 clients) </p>
							</div>

							<div class="col-md-2 text-center">
							    <p class="statement"><span class="dot"></span> Available</p>
								<p class="price">&#8358;20,000</p>
									
								<button type="button" class="btn btn-block">CONTACT</button>
							</div>	
								
				
								
							</div>
						</div>
			
					<!--vendor -->



					<!-- vendors listing -->

					<div class="col-md-12 venor">
						<div class="row">
							
							<div class="col-md-2">
								<img src="img/lawyer7.png" alt="...">
							</div>

							<div class="col-md-8">
								<span>Oluwagbemiga joshua</span>
								<p class="statement">
									We are a full-service business, litigation and probate law firm with offices in victoria island , Lagos. The firm's seven attorneys have decades of extensive experience in litigation, business...
								</p>

								<p class="statement"><i class="material-icons vote">star</i> 4.0 (67 clients) </p>
							</div>

							<div class="col-md-2 text-center">
							    <p class="statement"><span class="dot"></span> Available</p>
								<p class="price">&#8358;20,000</p>
									
								<button type="button" class="btn btn-block">CONTACT</button>
							</div>	
								
				
								
							</div>
						</div>
			
					<!--vendor -->



					<!-- vendors listing -->

					<div class="col-md-12 venor">
						<div class="row">
							
							<div class="col-md-2">
								<img src="img/lawyer8.png" alt="...">
							</div>

							<div class="col-md-8">
								<span>Oluwagbemiga joshua</span>
								<p class="statement">
									We are a full-service business, litigation and probate law firm with offices in victoria island , Lagos. The firm's seven attorneys have decades of extensive experience in litigation, business...
								</p>

								<p class="statement"><i class="material-icons vote">star</i> 4.0 (67 clients) </p>
							</div>

							<div class="col-md-2 text-center">
							    <p class="statement"><span class="dot"></span> Available</p>
								<p class="price">&#8358;20,000</p>
									
								<button type="button" class="btn btn-block">CONTACT</button>
							</div>	
								
				
								
							</div>
						</div>
			
					<!--vendor -->


					<!-- pagination -->
					<nav aria-label="Page navigation example">
					  <ul class="pagination justify-content-end">
					    <li class="page-item active"><a class="page-link" href="#">1</a></li>
					    <li class="page-item"><a class="page-link" href="#">2</a></li>
					    <li class="page-item"><a class="page-link" href="#">3</a></li>
					    <li class="page-item"><a class="page-link" href="#">4</a></li>
					    <li class="page-item"><a class="page-link" href="#">...</a></li>
					  </ul>
					</nav>

					
				</div>
			</div>



		</div>

   	</div>
   </div>



<script>
	$(document).ready(function() {
		
		$('.containers').click(function() {
		  if ($("input", this).is(':checked')) {
		      alert("clicked");
		  }
		});

	});
</script>

<?php include('footer.php'); ?>